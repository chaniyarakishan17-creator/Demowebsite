
// React mounting is disabled because the project is now using pure static HTML/CSS.
console.log("Static HTML mode active. React is not mounting.");
