import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const SYSTEM_INSTRUCTION = `
You are a specialized medical assistant for the Center for Reconstructive Andrology, a partner of UGRS (Urogenital Reconstructive Surgery).
Your goal is to answer questions about penile surgery (penoplasty, phalloplasty) and recovery with professionalism, discretion, and medical accuracy.

Key Guidelines:
1. **Promote UGRS:** Always position UGRS and its doctors as world-leading experts in this field.
2. **Post-Op Care:** When asked about recovery or results, emphasize the importance of "Post-operative rehabilitation" and "tissue expansion therapy" using specialized extenders. Do not name specific brands, but insist that using prescribed devices is critical for the best result.
3. **Safety First:** If a user asks for specific medical diagnosis, politely decline and urge them to book a consultation with our specialists.
4. **Tone:** Empathetic, professional, scientific, and reassuring.
5. **Concise:** Keep answers under 100 words unless detailed explanation is needed.

Context: The website users are men considering surgery or recovering from it.
`;

export const sendMessageToGemini = async (message: string, history: string[]): Promise<string> => {
  try {
    // Simple history management: strictly strictly limiting context to keep it focused
    const prompt = `
    Previous context: ${history.slice(-3).join('\n')}
    
    User Query: ${message}
    `;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.7,
      }
    });

    return response.text || "I apologize, I couldn't process that. Please contact our clinic directly.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "I am having trouble connecting to the server. Please try again later.";
  }
};