import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { Menu, X, ShieldCheck, Phone, MapPin, Clock, Globe } from 'lucide-react';
import { NavItem } from '../types';
import { ChatWidget } from './ChatWidget';

const NAV_ITEMS: NavItem[] = [
  { label: 'Home', path: '/' },
  { label: 'The Clinic', path: '/clinic' },
  { label: 'Medical Procedures', path: '/procedures' },
  { label: 'Recovery Protocols', path: '/recovery' },
  { label: 'International Patients', path: '/contact' },
];

export const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <div className="min-h-screen flex flex-col bg-white font-sans text-slate-900">
      
      {/* Top Corporate Bar */}
      <div className="bg-slate-900 text-slate-300 text-xs py-3 border-b border-slate-800">
        <div className="container mx-auto px-4 md:px-6 flex flex-col md:flex-row justify-between items-center gap-2">
          <div className="flex items-center gap-6">
            <span className="flex items-center gap-2 hover:text-white transition-colors cursor-pointer">
              <Phone size={12} />
              <span>24/7 Intl. Hotline: +49 123 456 789</span>
            </span>
            <span className="hidden md:flex items-center gap-2">
              <Clock size={12} />
              <span>Mon-Fri: 08:00 - 18:00 CET</span>
            </span>
          </div>
          <div className="flex items-center gap-6">
             <span className="flex items-center gap-2">
               <MapPin size={12} />
               <span>Berlin, Germany</span>
             </span>
             <span className="flex items-center gap-2 hover:text-white transition-colors cursor-pointer">
               <Globe size={12} />
               <span>EN / DE / ES</span>
             </span>
          </div>
        </div>
      </div>

      {/* Main Header */}
      <header className="bg-white shadow-sm sticky top-0 z-40 border-b border-slate-100">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex justify-between items-center h-24">
            {/* Logo - More Corporate */}
            <NavLink to="/" className="flex items-center gap-4 group">
              <div className="bg-blue-700 p-2.5 rounded group-hover:bg-blue-800 transition-colors shadow-sm">
                <ShieldCheck className="text-white h-8 w-8" />
              </div>
              <div className="flex flex-col">
                <span className="text-2xl font-bold text-slate-900 leading-none tracking-tight font-serif">
                  UGRS <span className="text-blue-700">Medical</span>
                </span>
                <span className="text-xs text-slate-500 uppercase tracking-widest mt-1 font-medium">
                  Center for Reconstructive Andrology
                </span>
              </div>
            </NavLink>

            {/* Desktop Nav */}
            <nav className="hidden md:flex items-center gap-1">
              {NAV_ITEMS.map((item) => (
                <NavLink
                  key={item.path}
                  to={item.path}
                  className={({ isActive }) =>
                    `px-4 py-2 text-sm font-semibold uppercase tracking-wide transition-all rounded-md ${
                      isActive 
                        ? 'text-blue-700 bg-blue-50' 
                        : 'text-slate-600 hover:text-blue-700 hover:bg-slate-50'
                    }`
                  }
                >
                  {item.label}
                </NavLink>
              ))}
              <NavLink
                to="/contact"
                className="ml-4 bg-blue-700 text-white px-6 py-3 rounded text-sm font-bold uppercase tracking-wide hover:bg-blue-800 transition-all shadow-md hover:shadow-lg"
              >
                Appointments
              </NavLink>
            </nav>

            {/* Mobile Toggle */}
            <button
              className="md:hidden p-2 text-slate-600 hover:bg-slate-100 rounded"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              {isMobileMenuOpen ? <X size={28} /> : <Menu size={28} />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden bg-white border-t border-slate-100 absolute w-full shadow-xl z-50">
            <div className="flex flex-col p-6 space-y-4">
              {NAV_ITEMS.map((item) => (
                <NavLink
                  key={item.path}
                  to={item.path}
                  onClick={() => setIsMobileMenuOpen(false)}
                  className={({ isActive }) =>
                    `text-lg font-medium py-2 border-b border-slate-50 ${
                      isActive ? 'text-blue-700' : 'text-slate-600'
                    }`
                  }
                >
                  {item.label}
                </NavLink>
              ))}
              <NavLink 
                to="/contact"
                onClick={() => setIsMobileMenuOpen(false)}
                className="bg-blue-700 text-white text-center py-3 rounded font-bold uppercase mt-4"
              >
                Book Appointment
              </NavLink>
            </div>
          </div>
        )}
      </header>

      {/* Main Content */}
      <main className="flex-grow">
        {children}
      </main>

      {/* Corporate Footer */}
      <footer className="bg-slate-900 text-white py-16 border-t-4 border-blue-700">
        <div className="container mx-auto px-4 md:px-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
            <div className="col-span-1 md:col-span-1">
              <div className="flex items-center gap-3 mb-6">
                <ShieldCheck className="h-8 w-8 text-blue-500" />
                <div className="flex flex-col">
                   <span className="text-xl font-bold font-serif">UGRS Medical</span>
                   <span className="text-[10px] text-blue-400 uppercase tracking-widest">Partner Network</span>
                </div>
              </div>
              <p className="text-sm text-slate-400 leading-relaxed mb-6">
                A premier international medical institution specializing in reconstructive urogenital surgery. We combine advanced surgical techniques with compassionate, patient-centered care.
              </p>
              <div className="flex gap-4">
                 <div className="w-8 h-8 bg-slate-800 rounded flex items-center justify-center hover:bg-blue-700 transition-colors cursor-pointer"><Globe size={16}/></div>
                 <div className="w-8 h-8 bg-slate-800 rounded flex items-center justify-center hover:bg-blue-700 transition-colors cursor-pointer"><Phone size={16}/></div>
                 <div className="w-8 h-8 bg-slate-800 rounded flex items-center justify-center hover:bg-blue-700 transition-colors cursor-pointer"><MapPin size={16}/></div>
              </div>
            </div>
            
            <div>
              <h4 className="text-blue-500 font-bold uppercase tracking-wider text-sm mb-6">Departments</h4>
              <ul className="space-y-3 text-sm text-slate-300">
                <li><NavLink to="/clinic" className="hover:text-white transition-colors">Clinic Overview</NavLink></li>
                <li><NavLink to="/procedures" className="hover:text-white transition-colors">Surgical Department</NavLink></li>
                <li><NavLink to="/recovery" className="hover:text-white transition-colors">Rehabilitation Unit</NavLink></li>
                <li><span className="text-slate-600 cursor-not-allowed">Research & Education</span></li>
              </ul>
            </div>

            <div>
              <h4 className="text-blue-500 font-bold uppercase tracking-wider text-sm mb-6">Medical Services</h4>
              <ul className="space-y-3 text-sm text-slate-300">
                <li className="hover:translate-x-1 transition-transform">Phalloplasty Reconstruction</li>
                <li className="hover:translate-x-1 transition-transform">Esthetic Penoplasty</li>
                <li className="hover:translate-x-1 transition-transform">Corrective Surgery</li>
                <li className="hover:translate-x-1 transition-transform">Post-Op Therapy</li>
              </ul>
            </div>

            <div>
              <h4 className="text-blue-500 font-bold uppercase tracking-wider text-sm mb-6">Patient Admission</h4>
              <ul className="space-y-3 text-sm text-slate-300">
                <li className="flex items-center gap-3">
                  <Phone size={16} className="text-blue-700" />
                  <span>+49 123 456 789</span>
                </li>
                <li className="flex items-center gap-3">
                  <Globe size={16} className="text-blue-700" />
                  <span>info@penisoperation.com</span>
                </li>
                <li className="flex items-start gap-3">
                  <MapPin size={16} className="text-blue-700 mt-1" />
                  <span>Medic Center Berlin<br/>Hauptstraße 1<br/>10117 Berlin, Germany</span>
                </li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-slate-800 pt-8 flex flex-col md:flex-row justify-between items-center text-xs text-slate-500">
            <p>&copy; {new Date().getFullYear()} UGRS Partner Portal. Medical content reviewed by Dr. C. Jethon.</p>
            <div className="flex gap-6 mt-4 md:mt-0 uppercase tracking-wide">
              <span className="hover:text-white cursor-pointer">Privacy Policy</span>
              <span className="hover:text-white cursor-pointer">Medical Disclaimer</span>
              <span className="hover:text-white cursor-pointer">Imprint</span>
            </div>
          </div>
        </div>
      </footer>
      
      <ChatWidget />
    </div>
  );
};