import React from 'react';
import { NavLink } from 'react-router-dom';
import { Clock, ShieldCheck, TrendingUp, AlertCircle, Droplets, BedDouble, ArrowUpCircle } from 'lucide-react';

export const Recovery: React.FC = () => {
  return (
    <div className="animate-fade-in pb-20 font-sans">
      <div className="bg-slate-50 py-20 border-b border-slate-200">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex items-center gap-2 mb-4 text-blue-700 font-bold uppercase tracking-widest text-xs">
            <TrendingUp size={14} />
            <span>Optimization Protocol</span>
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-slate-900 mb-6 font-serif">Post-Operative Care</h1>
          <p className="text-slate-600 max-w-3xl text-xl font-light leading-relaxed">
            The success of the procedure relies heavily on a disciplined post-operative rehabilitation protocol. We guide you through every stage to ensure maximum gain and rapid healing.
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 md:px-6 py-16">
        {/* 3 Pillars Section */}
        <div className="mb-24">
           <div className="text-center mb-16">
             <h2 className="text-3xl font-bold text-slate-900 font-serif">The 3 Pillars of Success</h2>
             <p className="text-slate-500 mt-4">Essential components of our recovery methodology</p>
           </div>
           
           <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
             <div className="bg-white p-8 rounded border border-slate-200 shadow-sm text-center group hover:border-blue-500 transition-colors">
                <div className="w-16 h-16 bg-slate-50 text-slate-400 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:bg-blue-50 group-hover:text-blue-600 transition-colors">
                  <BedDouble size={28} />
                </div>
                <h3 className="font-bold text-xl mb-4 text-slate-900 uppercase tracking-wide text-sm">1. Active Rest</h3>
                <p className="text-slate-600 text-sm leading-relaxed">
                  Allowing the initial incision to heal without tension is crucial in the first 7-10 days. Avoid gym, running, and heavy lifting to prevent scar widening.
                </p>
             </div>
             <div className="bg-white p-8 rounded border border-slate-200 shadow-sm text-center group hover:border-blue-500 transition-colors">
                <div className="w-16 h-16 bg-slate-50 text-slate-400 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:bg-blue-50 group-hover:text-blue-600 transition-colors">
                  <Droplets size={28} />
                </div>
                <h3 className="font-bold text-xl mb-4 text-slate-900 uppercase tracking-wide text-sm">2. Hygiene Protocol</h3>
                <p className="text-slate-600 text-sm leading-relaxed">
                  Strict hygiene protocols prevent infection. Daily cleaning and dressing changes as instructed by the surgeon are non-negotiable for a clean aesthetic result.
                </p>
             </div>
             <div className="bg-blue-50 p-8 rounded border-2 border-blue-500 shadow-md text-center relative">
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-blue-600 text-white text-[10px] font-bold uppercase px-3 py-1 rounded-full">Critical Success Factor</div>
                <div className="w-16 h-16 bg-white text-blue-600 rounded-full flex items-center justify-center mx-auto mb-6 shadow-sm">
                  <ArrowUpCircle size={28} />
                </div>
                <h3 className="font-bold text-xl mb-4 text-slate-900 uppercase tracking-wide text-sm">3. Mechanical Traction</h3>
                <p className="text-slate-700 text-sm leading-relaxed font-medium">
                  Using a medical extender device is essential to prevent the ligament from re-adhering. This "physiotherapy" phase creates the permanent length gain.
                </p>
             </div>
           </div>
        </div>

        {/* Timeline */}
        <div className="max-w-4xl mx-auto mb-24">
          <h2 className="text-2xl font-bold text-slate-900 mb-12 font-serif border-b border-slate-200 pb-4">Recovery Roadmap</h2>
          <div className="space-y-12 relative before:absolute before:inset-0 before:ml-5 before:-translate-x-px md:before:mx-auto md:before:translate-x-0 before:h-full before:w-0.5 before:bg-slate-200">
            
            {/* Step 1 */}
            <div className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group">
              <div className="flex items-center justify-center w-10 h-10 rounded-full border-4 border-white bg-slate-800 text-white shadow shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2 z-10">
                <span className="text-xs font-bold">1</span>
              </div>
              <div className="w-[calc(100%-4rem)] md:w-[calc(50%-2.5rem)] p-8 rounded bg-white border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
                <div className="flex justify-between items-center mb-2">
                  <h3 className="font-bold text-slate-900 uppercase tracking-wide text-sm">Days 1-7</h3>
                </div>
                <p className="text-slate-600 text-sm leading-relaxed">Immediate healing phase. Rest is critical. Mild dressing is applied. Avoid strenuous activity and keep the area dry.</p>
              </div>
            </div>

            {/* Step 2 */}
            <div className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group">
              <div className="flex items-center justify-center w-10 h-10 rounded-full border-4 border-white bg-blue-600 text-white shadow shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2 z-10">
                <span className="text-xs font-bold">2</span>
              </div>
              <div className="w-[calc(100%-4rem)] md:w-[calc(50%-2.5rem)] p-8 rounded bg-blue-50 border border-blue-200 shadow-sm">
                <div className="flex justify-between items-center mb-2">
                  <h3 className="font-bold text-blue-900 uppercase tracking-wide text-sm">Weeks 2-4: Active Phase</h3>
                </div>
                <p className="text-blue-800 text-sm leading-relaxed">
                  Start of <span className="font-bold">Active Rehabilitation</span>. To prevent ligament retraction and maximize length gains, specific traction protocols must be initiated.
                </p>
              </div>
            </div>

            {/* Step 3 */}
            <div className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group">
              <div className="flex items-center justify-center w-10 h-10 rounded-full border-4 border-white bg-slate-300 text-white shadow shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2 z-10">
                <span className="text-xs font-bold">3</span>
              </div>
              <div className="w-[calc(100%-4rem)] md:w-[calc(50%-2.5rem)] p-8 rounded bg-white border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
                <div className="flex justify-between items-center mb-2">
                  <h3 className="font-bold text-slate-900 uppercase tracking-wide text-sm">Months 2-6</h3>
                </div>
                <p className="text-slate-600 text-sm leading-relaxed">Long-term tissue expansion. Consistent use of prescribed devices ensures the gains become permanent and tissue quality remains high.</p>
              </div>
            </div>
          </div>
        </div>

        {/* The "Product" Pitch Area - Subtly Integrated */}
        <div className="mt-12 max-w-5xl mx-auto">
          <div className="bg-slate-900 rounded-lg p-10 md:p-14 text-white relative overflow-hidden shadow-2xl">
             <div className="absolute top-0 right-0 p-12 opacity-10">
               <TrendingUp size={200} />
             </div>
             <div className="relative z-10">
               <div className="flex items-start gap-4 mb-8">
                 <div className="bg-blue-600 p-3 rounded">
                   <AlertCircle size={32} className="text-white" />
                 </div>
                 <div>
                   <h3 className="text-2xl font-bold mb-2 font-serif">Medical Advisory: Traction Therapy</h3>
                   <p className="text-blue-300 text-xs font-bold uppercase tracking-widest">Standard of Care</p>
                 </div>
               </div>
               
               <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
                 <div>
                   <p className="text-slate-300 text-lg leading-relaxed mb-6 font-light">
                     Scientific studies show that the use of a medical-grade penile extender (traction device) post-surgery is <strong>mandatory</strong> to prevent retraction of the released ligament. Without this, surgical gains may be lost during the healing process.
                   </p>
                   <div className="p-6 bg-blue-900/50 rounded border border-blue-800">
                     <p className="italic text-blue-100 text-sm">
                       "We exclusively recommend FDA/CE approved traction devices as part of our post-op package. Our doctors will guide you on the specific device best suited for your anatomy during your consultation."
                     </p>
                   </div>
                 </div>
                 
                 <div className="space-y-4">
                   <div className="bg-white/5 p-6 rounded border border-white/10">
                      <h4 className="font-bold text-white mb-2 text-sm uppercase tracking-wide">Prevents Retraction</h4>
                      <p className="text-sm text-slate-400">Maintains tension on the healing ligament to ensure new length is preserved.</p>
                   </div>
                   <div className="bg-white/5 p-6 rounded border border-white/10">
                      <h4 className="font-bold text-white mb-2 text-sm uppercase tracking-wide">Straightening Effect</h4>
                      <p className="text-sm text-slate-400">Assists in correcting minor curvature and ensures straight healing during remodeling.</p>
                   </div>
                   <div className="mt-6">
                      <NavLink to="/contact" className="inline-block bg-white text-slate-900 px-8 py-3 rounded font-bold uppercase tracking-wide hover:bg-slate-200 transition-colors w-full text-center">
                        Request Protocol Details
                      </NavLink>
                   </div>
                 </div>
               </div>

             </div>
          </div>
        </div>

      </div>
    </div>
  );
};