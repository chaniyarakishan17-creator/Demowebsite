import React, { useState } from 'react';
import { Phone, Mail, MapPin, Send, MessageSquare, Calendar, Plane, UserCheck } from 'lucide-react';

export const Contact: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    message: ''
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate submission
    setTimeout(() => setSubmitted(true), 1000);
  };

  return (
    <div className="animate-fade-in bg-slate-50 min-h-screen">
      <div className="bg-white py-16 border-b border-slate-200">
        <div className="container mx-auto px-4 md:px-6 text-center">
          <h1 className="text-4xl font-bold text-slate-900 mb-4">Start Your Journey</h1>
          <p className="text-slate-600 max-w-xl mx-auto">
            Discreet, professional, and confidential. Contact us to schedule an initial consultation with Dr. Jethon and the UGRS team.
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 md:px-6 py-16">
        
        {/* Process Timeline - New Section */}
        <div className="mb-20">
          <h2 className="text-2xl font-bold text-slate-900 mb-10 text-center">The Consultation Process</h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 relative">
             <div className="hidden md:block absolute top-1/2 left-0 w-full h-0.5 bg-slate-200 -z-10 -translate-y-1/2"></div>
             
             {[
               { icon: <MessageSquare size={20} />, title: "1. Inquiry", desc: "Send us your request via the form below." },
               { icon: <Calendar size={20} />, title: "2. Consultation", desc: "Video call with our medical coordinator." },
               { icon: <Plane size={20} />, title: "3. Planning", desc: "We assist with dates and travel logistics." },
               { icon: <UserCheck size={20} />, title: "4. Confirmation", desc: "Secure your surgery date with a deposit." }
             ].map((step, i) => (
               <div key={i} className="bg-white p-6 rounded-xl border border-slate-100 shadow-sm text-center flex flex-col items-center">
                 <div className="w-12 h-12 bg-blue-600 text-white rounded-full flex items-center justify-center mb-4 border-4 border-white shadow-sm">
                   {step.icon}
                 </div>
                 <h3 className="font-bold text-slate-900 mb-1">{step.title}</h3>
                 <p className="text-sm text-slate-500">{step.desc}</p>
               </div>
             ))}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          
          {/* Form */}
          <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100">
            {submitted ? (
              <div className="h-full flex flex-col items-center justify-center text-center py-20">
                <div className="w-16 h-16 bg-green-100 text-green-600 rounded-full flex items-center justify-center mb-6">
                  <Send size={32} />
                </div>
                <h3 className="text-2xl font-bold text-slate-900 mb-2">Message Sent</h3>
                <p className="text-slate-600">Thank you for contacting us. Our coordinator will reach out to you within 24 hours.</p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <h3 className="text-xl font-bold text-slate-900 mb-6">Request Consultation</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Full Name</label>
                    <input 
                      required 
                      type="text" 
                      className="w-full px-4 py-3 rounded-lg border border-slate-200 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
                      placeholder="John Doe"
                      value={formData.name}
                      onChange={e => setFormData({...formData, name: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Phone Number</label>
                    <input 
                      required 
                      type="tel" 
                      className="w-full px-4 py-3 rounded-lg border border-slate-200 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
                      placeholder="+1 (555) 000-0000"
                      value={formData.phone}
                      onChange={e => setFormData({...formData, phone: e.target.value})}
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Email Address</label>
                  <input 
                    required 
                    type="email" 
                    className="w-full px-4 py-3 rounded-lg border border-slate-200 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
                    placeholder="john@example.com"
                    value={formData.email}
                    onChange={e => setFormData({...formData, email: e.target.value})}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">How can we help?</label>
                  <textarea 
                    rows={4}
                    className="w-full px-4 py-3 rounded-lg border border-slate-200 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
                    placeholder="I am interested in..."
                    value={formData.message}
                    onChange={e => setFormData({...formData, message: e.target.value})}
                  ></textarea>
                </div>
                <button 
                  type="submit" 
                  className="w-full bg-blue-600 text-white font-bold py-4 rounded-lg hover:bg-blue-700 transition-colors shadow-lg shadow-blue-900/10"
                >
                  Send Inquiry
                </button>
                <p className="text-xs text-slate-400 text-center mt-4">
                  Your information is held in strict confidence and complies with medical privacy laws.
                </p>
              </form>
            )}
          </div>

          {/* Contact Info */}
          <div className="space-y-8">
            <div>
              <h3 className="text-2xl font-bold text-slate-900 mb-6">Contact Information</h3>
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="bg-white p-3 rounded-lg shadow-sm border border-slate-100 text-blue-600">
                    <MapPin size={24} />
                  </div>
                  <div>
                    <h4 className="font-semibold text-slate-900">UGRS Germany</h4>
                    <p className="text-slate-600">Center for Reconstructive Andrology<br />Example Street 123<br />Berlin, Germany</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="bg-white p-3 rounded-lg shadow-sm border border-slate-100 text-blue-600">
                    <Phone size={24} />
                  </div>
                  <div>
                    <h4 className="font-semibold text-slate-900">Phone</h4>
                    <p className="text-slate-600">+49 123 456 789<br /><span className="text-sm text-slate-400">Mon-Fri: 9am - 5pm CET</span></p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="bg-white p-3 rounded-lg shadow-sm border border-slate-100 text-blue-600">
                    <Mail size={24} />
                  </div>
                  <div>
                    <h4 className="font-semibold text-slate-900">Email</h4>
                    <p className="text-slate-600">info@penisoperation.com</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-slate-900 text-white p-8 rounded-2xl">
              <h4 className="font-bold mb-4">International Patients</h4>
              <p className="text-slate-300 text-sm leading-relaxed mb-4">
                We assist international patients with travel arrangements, hotel bookings near the clinic, and translation services.
              </p>
              <button className="text-blue-400 font-semibold hover:text-blue-300 text-sm">
                Download Patient Guide &rarr;
              </button>
            </div>
            
            {/* Map Placeholder */}
            <div className="w-full h-48 bg-slate-200 rounded-2xl overflow-hidden relative">
               <img src="https://images.unsplash.com/photo-1524661135-423995f22d0b?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80" className="w-full h-full object-cover opacity-50 grayscale" alt="Map Location" />
               <div className="absolute inset-0 flex items-center justify-center">
                 <div className="bg-white/90 backdrop-blur px-4 py-2 rounded-lg text-xs font-bold shadow-sm">
                   Berlin, Germany
                 </div>
               </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};