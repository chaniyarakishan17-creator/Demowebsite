import React from 'react';
import { NavLink } from 'react-router-dom';
import { Activity, Plus, ShieldAlert, Stethoscope, Calendar, ArrowRight, ChevronRight, FileText } from 'lucide-react';

export const Procedures: React.FC = () => {
  return (
    <div className="animate-fade-in">
      {/* Header */}
      <div className="bg-slate-900 text-white py-24 relative overflow-hidden">
        <div className="absolute right-0 top-0 w-1/3 h-full bg-blue-600/10 skew-x-12 transform origin-top-right"></div>
        <div className="container mx-auto px-4 md:px-6 relative z-10">
          <h1 className="text-4xl md:text-5xl font-bold mb-6 font-serif">Surgical Department</h1>
          <p className="text-slate-300 max-w-2xl text-xl font-light leading-relaxed">
            Our surgical interventions utilize evidence-based, minimally invasive techniques tailored to individual anatomical requirements.
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 md:px-6 py-20">
        
        {/* Procedure Cards - Corporate Style */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 mb-24">
          
          {/* Procedure 1 */}
          <div className="bg-white rounded-lg overflow-hidden border border-slate-200 shadow-lg group">
            <div className="bg-blue-600 p-1"></div>
            <div className="p-10">
              <div className="flex justify-between items-start mb-6">
                <div className="w-16 h-16 bg-blue-50 text-blue-700 rounded-lg flex items-center justify-center border border-blue-100">
                  <Plus size={32} />
                </div>
                <span className="bg-slate-100 text-slate-600 px-3 py-1 text-xs font-bold uppercase tracking-widest rounded">Surgical</span>
              </div>
              
              <h2 className="text-3xl font-bold text-slate-900 mb-4 font-serif">Ligamentolysis (Lengthening)</h2>
              <p className="text-slate-600 mb-8 leading-relaxed text-lg">
                A reconstructive procedure releasing the suspensory ligament to externalize the hidden portion of the penile shaft. This increases flaccid length while preserving functionality.
              </p>
              
              <div className="bg-slate-50 p-6 rounded-lg border border-slate-100 mb-8">
                <h4 className="font-bold text-slate-900 mb-4 uppercase text-sm tracking-wide border-b border-slate-200 pb-2">Clinical Protocol</h4>
                <ul className="space-y-3">
                  <li className="flex items-start gap-3">
                    <ChevronRight className="text-blue-500 w-5 h-5 flex-shrink-0" />
                    <span className="text-slate-700 text-sm">Minimally invasive infra-pubic incision</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <ChevronRight className="text-blue-500 w-5 h-5 flex-shrink-0" />
                    <span className="text-slate-700 text-sm">Advanced suture technique for hidden scarring</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <ChevronRight className="text-blue-500 w-5 h-5 flex-shrink-0" />
                    <span className="text-slate-900 text-sm font-semibold">Post-op traction therapy required for 3-6 months</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>

          {/* Procedure 2 */}
          <div className="bg-white rounded-lg overflow-hidden border border-slate-200 shadow-lg group">
            <div className="bg-blue-600 p-1"></div>
            <div className="p-10">
              <div className="flex justify-between items-start mb-6">
                <div className="w-16 h-16 bg-blue-50 text-blue-700 rounded-lg flex items-center justify-center border border-blue-100">
                  <Activity size={32} />
                </div>
                <span className="bg-slate-100 text-slate-600 px-3 py-1 text-xs font-bold uppercase tracking-widest rounded">Aesthetic</span>
              </div>
              
              <h2 className="text-3xl font-bold text-slate-900 mb-4 font-serif">Autologous Girth Enhancement</h2>
              <p className="text-slate-600 mb-8 leading-relaxed text-lg">
                Circumference augmentation using the patient's own adipose tissue (fat). The tissue is harvested, purified via centrifugation, and re-injected for natural volume increase.
              </p>
              
              <div className="bg-slate-50 p-6 rounded-lg border border-slate-100 mb-8">
                <h4 className="font-bold text-slate-900 mb-4 uppercase text-sm tracking-wide border-b border-slate-200 pb-2">Clinical Protocol</h4>
                <ul className="space-y-3">
                  <li className="flex items-start gap-3">
                    <ChevronRight className="text-blue-500 w-5 h-5 flex-shrink-0" />
                    <span className="text-slate-700 text-sm">Liposuction from abdomen or inner thighs</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <ChevronRight className="text-blue-500 w-5 h-5 flex-shrink-0" />
                    <span className="text-slate-700 text-sm">Multi-plane injection for smooth contour</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <ChevronRight className="text-blue-500 w-5 h-5 flex-shrink-0" />
                    <span className="text-slate-900 text-sm font-semibold">Zero rejection risk (Autologous tissue)</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        {/* Safety & Standards - Two Column Text */}
        <div className="mb-24">
           <div className="border-l-4 border-blue-600 pl-6 mb-10">
              <h2 className="text-3xl font-bold text-slate-900 font-serif">Safety Protocols & Anesthesia</h2>
              <p className="text-slate-500 mt-2 uppercase tracking-wide text-sm font-semibold">ISO 9001:2015 Compliant</p>
           </div>
           
           <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
             <div className="prose prose-slate">
                <h3 className="text-xl font-bold text-slate-900 flex items-center gap-2">
                  <ShieldAlert size={20} className="text-blue-600"/> Anesthesia Management
                </h3>
                <p className="text-slate-600 leading-relaxed">
                  We prioritize patient comfort and safety. Most lengthening and girth procedures are performed under **Twilight Sedation (TIVA)** or total intravenous anesthesia. This ensures you are asleep and pain-free, without the deeper risks and recovery time associated with intubation. All anesthesia is managed by dedicated senior anesthesiologists.
                </p>
             </div>
             <div className="prose prose-slate">
                <h3 className="text-xl font-bold text-slate-900 flex items-center gap-2">
                  <Stethoscope size={20} className="text-blue-600"/> Pre-Operative Assessment
                </h3>
                <p className="text-slate-600 leading-relaxed">
                  Rigorous screening is mandatory. This includes a full coagulation profile, blood count, and ECG for patients over 40. We review all medications to mitigate bleeding risks. Our "Safety First" approach means we only proceed when all physiological parameters are optimal.
                </p>
             </div>
           </div>
        </div>

        {/* Roadmap - Horizontal Steps */}
        <div className="bg-slate-50 rounded-xl p-10 border border-slate-200 mb-16">
          <h2 className="text-2xl font-bold text-slate-900 mb-10 text-center font-serif">The Surgical Pathway</h2>
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            {[
              { title: "Consultation", sub: "Virtual Assessment", icon: <FileText size={20}/> },
              { title: "Pre-Op", sub: "Labs & Logistics", icon: <Calendar size={20}/> },
              { title: "Surgery", sub: "60-90 Minutes", icon: <Activity size={20}/> },
              { title: "Observation", sub: "24h Monitoring", icon: <Stethoscope size={20}/> },
              { title: "Discharge", sub: "Return Home", icon: <ArrowRight size={20}/> }
            ].map((step, i) => (
              <div key={i} className="relative flex flex-col items-center text-center group">
                 <div className="w-12 h-12 rounded-full bg-white border-2 border-slate-300 flex items-center justify-center text-slate-400 mb-4 group-hover:border-blue-500 group-hover:text-blue-500 transition-colors z-10">
                   {step.icon}
                 </div>
                 {i < 4 && (
                   <div className="hidden md:block absolute top-6 left-1/2 w-full h-0.5 bg-slate-200 -z-0"></div>
                 )}
                 <h4 className="font-bold text-slate-900 text-sm">{step.title}</h4>
                 <p className="text-xs text-slate-500">{step.sub}</p>
              </div>
            ))}
          </div>
        </div>

        {/* CTA */}
        <div className="text-center">
          <p className="text-slate-600 mb-6 max-w-2xl mx-auto">
            Each case is unique. We strongly recommend a personal consultation to discuss your specific anatomical goals and medical history.
          </p>
          <NavLink to="/contact" className="inline-flex items-center gap-2 bg-blue-700 text-white px-10 py-4 rounded font-bold uppercase tracking-wide hover:bg-blue-800 transition-all shadow-lg">
            Request Medical Consultation <ArrowRight size={18} />
          </NavLink>
        </div>
      </div>
    </div>
  );
};