import React from 'react';
import { NavLink } from 'react-router-dom';
import { ArrowRight, CheckCircle, Shield, Award, Activity, Star, HelpCircle, Users, ClipboardCheck, Microscope } from 'lucide-react';

export const Home: React.FC = () => {
  return (
    <div className="animate-fade-in font-sans">
      {/* Hero Section */}
      <section className="relative h-[80vh] min-h-[600px] flex items-center bg-slate-900 overflow-hidden">
        {/* Background Image with Overlay */}
        <div className="absolute inset-0 opacity-40 bg-[url('https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?ixlib=rb-4.0.3&auto=format&fit=crop&w=2000&q=80')] bg-cover bg-center"></div>
        <div className="absolute inset-0 bg-gradient-to-r from-slate-900 via-slate-900/80 to-slate-900/30"></div>
        
        <div className="container mx-auto px-4 md:px-6 relative z-10">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-3 px-4 py-2 rounded-sm bg-blue-600/20 border-l-4 border-blue-500 backdrop-blur-md mb-8">
              <span className="text-blue-400 font-bold uppercase tracking-widest text-xs">Excellence in Reconstructive Andrology</span>
            </div>
            
            <h1 className="text-5xl md:text-7xl font-bold text-white mb-8 leading-[1.1] tracking-tight">
              Advanced Surgical <br/>
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-blue-200">Solutions for Men</span>
            </h1>
            
            <p className="text-xl text-slate-300 mb-10 leading-relaxed max-w-2xl font-light">
              The UGRS Partner Center provides world-class medical expertise in penile reconstruction and enhancement. Minimally invasive techniques. Maximum patient safety.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-5">
              <NavLink 
                to="/contact" 
                className="bg-blue-600 text-white px-8 py-4 rounded-md font-bold uppercase tracking-wide hover:bg-blue-700 transition-all shadow-xl shadow-blue-900/20 text-center flex items-center justify-center gap-3"
              >
                Request Consultation <ArrowRight size={20} />
              </NavLink>
              <NavLink 
                to="/procedures" 
                className="bg-transparent border border-white/30 backdrop-blur-sm text-white px-8 py-4 rounded-md font-bold uppercase tracking-wide hover:bg-white/10 transition-all text-center"
              >
                Explore Procedures
              </NavLink>
            </div>
          </div>
        </div>
      </section>

      {/* Statistics Banner - New */}
      <section className="bg-blue-700 py-12 relative z-20 -mt-8 mx-4 md:mx-0 rounded-xl md:rounded-none shadow-xl">
        <div className="container mx-auto px-4 md:px-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center text-white">
            <div className="p-4">
              <div className="text-4xl md:text-5xl font-bold mb-2">15+</div>
              <div className="text-blue-200 text-sm uppercase tracking-widest font-semibold">Years Experience</div>
            </div>
            <div className="p-4 border-l border-blue-600/50">
              <div className="text-4xl md:text-5xl font-bold mb-2">5k+</div>
              <div className="text-blue-200 text-sm uppercase tracking-widest font-semibold">Procedures</div>
            </div>
            <div className="p-4 border-l border-blue-600/50">
              <div className="text-4xl md:text-5xl font-bold mb-2">ISO</div>
              <div className="text-blue-200 text-sm uppercase tracking-widest font-semibold">9001 Certified</div>
            </div>
            <div className="p-4 border-l border-blue-600/50">
              <div className="text-4xl md:text-5xl font-bold mb-2">100%</div>
              <div className="text-blue-200 text-sm uppercase tracking-widest font-semibold">Confidential</div>
            </div>
          </div>
        </div>
      </section>

      {/* Corporate Trust Section */}
      <section className="py-24 bg-white">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-16 max-w-3xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-6 font-serif">Why Choose UGRS Partner Center?</h2>
            <p className="text-slate-600 text-lg leading-relaxed">
              We operate at the intersection of medical science and patient-centered care. Our facility is equipped with the latest technology to ensure superior outcomes.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            <div className="flex flex-col items-center text-center p-8 bg-slate-50 rounded-lg border border-slate-100 hover:shadow-lg transition-all duration-300 group">
              <div className="w-16 h-16 bg-white text-blue-700 rounded-full flex items-center justify-center mb-6 shadow-md border border-slate-100 group-hover:scale-110 transition-transform">
                <Shield size={32} />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-3 uppercase tracking-wide">Clinical Safety</h3>
              <p className="text-slate-600 leading-relaxed">
                Operating in full compliance with German medical standards and international hygiene protocols for zero-compromise safety.
              </p>
            </div>
            <div className="flex flex-col items-center text-center p-8 bg-slate-50 rounded-lg border border-slate-100 hover:shadow-lg transition-all duration-300 group">
              <div className="w-16 h-16 bg-white text-blue-700 rounded-full flex items-center justify-center mb-6 shadow-md border border-slate-100 group-hover:scale-110 transition-transform">
                <Microscope size={32} />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-3 uppercase tracking-wide">Advanced Techniques</h3>
              <p className="text-slate-600 leading-relaxed">
                Pioneering minimally invasive surgical methods that reduce downtime and enhance aesthetic results naturally.
              </p>
            </div>
            <div className="flex flex-col items-center text-center p-8 bg-slate-50 rounded-lg border border-slate-100 hover:shadow-lg transition-all duration-300 group">
              <div className="w-16 h-16 bg-white text-blue-700 rounded-full flex items-center justify-center mb-6 shadow-md border border-slate-100 group-hover:scale-110 transition-transform">
                <ClipboardCheck size={32} />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-3 uppercase tracking-wide">Structured Aftercare</h3>
              <p className="text-slate-600 leading-relaxed">
                A comprehensive post-operative roadmap including scheduled check-ups and specialized rehabilitation devices.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Feature Split Section */}
      <section className="py-24 bg-slate-50 border-y border-slate-200">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex flex-col lg:flex-row items-center gap-16">
            <div className="w-full lg:w-1/2 relative">
              <div className="absolute -top-4 -left-4 w-24 h-24 bg-blue-600 rounded-tl-3xl opacity-20"></div>
              <div className="absolute -bottom-4 -right-4 w-24 h-24 bg-blue-600 rounded-br-3xl opacity-20"></div>
              <img 
                src="https://images.unsplash.com/photo-1579684385127-1ef15d508118?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80" 
                alt="State of the art facility" 
                className="rounded-lg shadow-2xl relative z-10 w-full object-cover h-[500px]"
              />
            </div>
            <div className="w-full lg:w-1/2">
              <div className="inline-block px-3 py-1 bg-blue-100 text-blue-700 text-xs font-bold uppercase tracking-widest rounded mb-6">Medical Excellence</div>
              <h2 className="text-4xl font-bold text-slate-900 mb-6 font-serif">
                A Center of Authority in <br/>Reconstructive Surgery
              </h2>
              <p className="text-slate-600 text-lg mb-8 leading-relaxed">
                Our partnership with UGRS allows us to offer patients access to some of the world's most experienced surgeons. We treat medical conditions and aesthetic concerns with the same level of rigorous scientific methodology.
              </p>
              
              <div className="space-y-6">
                {[
                  { title: "Board Certified Surgeons", desc: "Specialists with specific focus on urogenital anatomy." },
                  { title: "Private Hospital Suites", desc: "Discrete recovery environments with 24/7 nursing." },
                  { title: "International Patient Desk", desc: "Full logistical support for traveling patients." }
                ].map((item, i) => (
                  <div key={i} className="flex gap-4">
                    <div className="mt-1">
                      <CheckCircle className="text-blue-600 w-6 h-6" />
                    </div>
                    <div>
                      <h4 className="text-lg font-bold text-slate-900">{item.title}</h4>
                      <p className="text-slate-600">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-10">
                <NavLink to="/clinic" className="text-blue-700 font-bold uppercase tracking-wide hover:text-blue-900 flex items-center gap-2 border-b-2 border-blue-200 hover:border-blue-700 pb-1 inline-flex transition-all">
                  Tour our Facility <ArrowRight size={16} />
                </NavLink>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Patient Stories - More Formal */}
      <section className="py-24 bg-white">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-6">
             <div>
               <h2 className="text-3xl font-bold text-slate-900 mb-4 font-serif">Patient Perspectives</h2>
               <p className="text-slate-600 max-w-xl">Real feedback from patients who have undergone treatment at our center.</p>
             </div>
             <NavLink to="/contact" className="text-blue-700 font-bold hover:underline">Read Medical Reviews &rarr;</NavLink>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                text: "The medical team's attention to detail was impressive. I felt I was in the safest hands possible.",
                author: "Patient ID: 4920",
                location: "United Kingdom",
                procedure: "Reconstructive Penoplasty"
              },
              {
                text: "From the airport transfer to the post-op kit, the level of organization is world-class.",
                author: "Patient ID: 3318",
                location: "United States",
                procedure: "Correction Surgery"
              },
              {
                text: "The doctor explained everything scientifically, no false promises. The outcome matched the prognosis perfectly.",
                author: "Patient ID: 5102",
                location: "Switzerland",
                procedure: "Aesthetic Enhancement"
              }
            ].map((t, i) => (
              <div key={i} className="bg-slate-50 p-10 rounded-xl border border-slate-100 flex flex-col relative">
                <div className="absolute top-8 right-8 text-slate-200">
                  <Activity size={40} />
                </div>
                <div className="flex text-blue-600 mb-6">
                  {[...Array(5)].map((_, k) => <Star key={k} size={14} fill="currentColor" />)}
                </div>
                <p className="text-slate-700 italic mb-8 flex-grow text-lg font-light leading-relaxed">"{t.text}"</p>
                <div className="border-t border-slate-200 pt-6">
                  <p className="font-bold text-slate-900 uppercase tracking-wide text-sm">{t.author}</p>
                  <p className="text-xs text-slate-500 mt-1">{t.location} • {t.procedure}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Accordion Style - Clean */}
      <section className="py-24 bg-slate-50 border-t border-slate-200">
        <div className="container mx-auto px-4 md:px-6 max-w-4xl">
          <div className="text-center mb-16">
             <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-100 text-blue-700 rounded-full mb-6">
                <HelpCircle size={32} />
             </div>
             <h2 className="text-3xl font-bold text-slate-900 font-serif">Medical FAQ</h2>
             <p className="text-slate-500 mt-4">Common questions regarding surgical intervention and recovery.</p>
          </div>
          
          <div className="space-y-4">
            {[
              {
                q: "Are the surgical results permanent?",
                a: "Yes. Ligamentolysis and autologous tissue transfer provide permanent structural changes. Long-term stability is supported by our mandatory post-operative mechanical traction protocol."
              },
              {
                q: "What is the typical recovery timeline?",
                a: "Patients are discharged within 24 hours. Social recovery (returning to office work) is typically 3-5 days. Physiological recovery (resuming sexual function) requires 4-6 weeks of healing."
              },
              {
                q: "How is patient confidentiality handled?",
                a: "We adhere to strict GDPR and medical confidentiality laws. All patient data is encrypted, and our facility is designed to ensure privacy during your stay."
              }
            ].map((faq, i) => (
              <div key={i} className="bg-white border border-slate-200 rounded-lg p-6 md:p-8 hover:border-blue-300 transition-colors shadow-sm">
                <h3 className="text-lg font-bold text-slate-900 mb-3 flex items-start gap-3">
                  <span className="text-blue-500 mt-1"><HelpCircle size={16}/></span>
                  {faq.q}
                </h3>
                <p className="text-slate-600 leading-relaxed pl-8 border-l-2 border-slate-100 ml-1">{faq.a}</p>
              </div>
            ))}
          </div>
          <div className="text-center mt-12">
            <NavLink to="/contact" className="inline-block bg-white border border-slate-300 text-slate-700 px-8 py-3 rounded font-bold uppercase tracking-wide hover:bg-slate-50 transition-colors">
              Contact Medical Team
            </NavLink>
          </div>
        </div>
      </section>
    </div>
  );
};