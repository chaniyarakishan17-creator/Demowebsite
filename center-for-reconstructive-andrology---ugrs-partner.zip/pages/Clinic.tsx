import React from 'react';
import { NavLink } from 'react-router-dom';
import { Globe, Heart, Stethoscope, Plane, Building, ShieldCheck, Wifi, Coffee, Star } from 'lucide-react';

export const Clinic: React.FC = () => {
  return (
    <div className="animate-fade-in pb-20 font-sans">
      {/* Page Header */}
      <div className="bg-slate-100 py-20 border-b border-slate-200">
        <div className="container mx-auto px-4 md:px-6 text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-slate-900 mb-6 font-serif">The Medical Center</h1>
          <p className="text-slate-600 max-w-3xl mx-auto text-xl font-light leading-relaxed">
            A center of excellence dedicated to urogenital health, utilizing state-of-the-art facilities and governed by strict medical ethics.
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 md:px-6 py-16">
        {/* Intro Section */}
        <div className="flex flex-col md:flex-row gap-16 items-center mb-24">
          <div className="w-full md:w-1/2">
            <div className="inline-block px-3 py-1 bg-slate-200 text-slate-700 text-xs font-bold uppercase tracking-widest rounded mb-6">International Standard</div>
            <h2 className="text-3xl font-bold text-slate-900 mb-6 font-serif">UGRS: A Legacy of Care</h2>
            <p className="text-slate-600 mb-6 leading-relaxed text-lg">
              The Center for Reconstructive Andrology (UGRS) represents the pinnacle of specialized surgical care. Our facilities are designed to provide a comfortable, private, and sterile environment for all patients.
            </p>
            <p className="text-slate-600 mb-6 leading-relaxed">
              Located in Germany, we serve an international clientele seeking the highest quality of medical intervention. From the initial consultation to the final post-operative checkup, our team is dedicated to your well-being.
            </p>
          </div>
          <div className="w-full md:w-1/2 grid grid-cols-2 gap-4">
            <img src="https://images.unsplash.com/photo-1516549655169-df83a0674503?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80" className="rounded shadow-lg mt-8" alt="Clinic Interior" />
            <img src="https://images.unsplash.com/photo-1629909613654-28e377c37b09?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80" className="rounded shadow-lg" alt="Surgical Theater" />
          </div>
        </div>

        {/* Head of Department Card */}
        <div className="mb-24 bg-white rounded-xl shadow-2xl border border-slate-100 overflow-hidden">
          <div className="flex flex-col md:flex-row">
             <div className="md:w-2/5 bg-slate-200 relative min-h-[400px]">
               <img 
                 src="https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" 
                 alt="Dr. Med. Representative" 
                 className="w-full h-full object-cover absolute inset-0"
               />
             </div>
             <div className="p-10 md:w-3/5 flex flex-col justify-center">
               <div className="mb-4">
                 <h3 className="text-3xl font-bold text-slate-900 font-serif">Dr. med. Christoph Jethon</h3>
                 <p className="text-blue-700 font-bold uppercase tracking-wide text-sm mt-2">Lead Surgeon, Department of Andrology</p>
               </div>
               <p className="text-slate-600 mb-8 leading-relaxed text-lg">
                 With over 20 years of experience in reconstructive surgery, Dr. Jethon is a recognized authority in the field. He specializes in functional and aesthetic corrections, ensuring that every procedure is tailored to the individual anatomy and goals of the patient.
               </p>
               <div className="flex flex-wrap gap-3">
                 <span className="px-4 py-2 bg-slate-100 text-slate-700 border border-slate-200 text-xs font-bold uppercase tracking-wide">Board Certified</span>
                 <span className="px-4 py-2 bg-slate-100 text-slate-700 border border-slate-200 text-xs font-bold uppercase tracking-wide">Urology Specialist</span>
                 <span className="px-4 py-2 bg-slate-100 text-slate-700 border border-slate-200 text-xs font-bold uppercase tracking-wide">Research Fellow</span>
               </div>
             </div>
          </div>
        </div>

        {/* Facilities Grid */}
        <div className="mb-24">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-slate-900 font-serif">Infrastructure & Amenities</h2>
            <div className="w-24 h-1 bg-blue-600 mx-auto mt-6"></div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
             {[
               { icon: <ShieldCheck size={32} />, title: "ISO Certified", desc: "Adhering to strict European safety standards." },
               { icon: <Stethoscope size={32} />, title: "Hybrid ORs", desc: "Advanced operating theaters for minimally invasive work." },
               { icon: <Wifi size={32} />, title: "Private Suites", desc: "Recovery rooms designed for comfort and discretion." },
               { icon: <Heart size={32} />, title: "24/7 Care", desc: "Round-the-clock nursing staff post-surgery." }
             ].map((item, i) => (
               <div key={i} className="bg-slate-50 p-8 rounded border border-slate-200 text-center hover:bg-white hover:shadow-xl transition-all duration-300 group">
                 <div className="text-slate-400 mb-6 group-hover:text-blue-600 transition-colors flex justify-center">
                   {item.icon}
                 </div>
                 <h3 className="font-bold text-slate-900 mb-3 uppercase tracking-wide text-sm">{item.title}</h3>
                 <p className="text-slate-600 text-sm leading-relaxed">{item.desc}</p>
               </div>
             ))}
          </div>
        </div>

        {/* International Support Banner */}
        <div className="bg-blue-900 text-white rounded-xl p-8 md:p-16 overflow-hidden relative shadow-2xl">
          <div className="absolute top-0 right-0 opacity-5 pointer-events-none transform scale-150 translate-x-1/4 -translate-y-1/4">
            <Globe size={400} />
          </div>
          <div className="relative z-10 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-block bg-blue-600/50 border border-blue-500/50 text-blue-100 text-xs font-bold px-3 py-1 rounded mb-6 uppercase tracking-widest">Concierge Services</div>
              <h2 className="text-3xl md:text-4xl font-bold mb-6 font-serif">International Patient Support</h2>
              <p className="text-blue-100 mb-8 leading-relaxed text-lg font-light">
                We understand that traveling for surgery can be daunting. Our international coordination team handles the logistics so you can focus entirely on your recovery.
              </p>
              <ul className="space-y-4 mb-8">
                <li className="flex items-center gap-4">
                  <div className="bg-blue-800 p-2 rounded"><Plane size={16} /></div>
                  <span className="font-medium">Airport pickup and VIP transfer service</span>
                </li>
                <li className="flex items-center gap-4">
                  <div className="bg-blue-800 p-2 rounded"><Building size={16} /></div>
                  <span className="font-medium">Partnerships with nearby 5-star hotels</span>
                </li>
                <li className="flex items-center gap-4">
                  <div className="bg-blue-800 p-2 rounded"><Coffee size={16} /></div>
                  <span className="font-medium">Multi-lingual staff (English, German, French, Spanish)</span>
                </li>
              </ul>
              <NavLink to="/contact" className="inline-block bg-white text-blue-900 px-8 py-4 rounded font-bold uppercase tracking-wide hover:bg-blue-50 transition-colors">
                Plan Your Visit
              </NavLink>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};